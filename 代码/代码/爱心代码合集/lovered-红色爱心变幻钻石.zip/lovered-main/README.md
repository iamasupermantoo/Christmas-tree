# lovered
红色的好看的爱心
![image](https://github.com/love99you/lovered/assets/118249630/0cc32c68-e5af-4924-8212-afcb6043b816)
